total_belanja = int((input"Masukkan total belanja :"))
regular = Rp 40000
VIP = Rp 75000
VVIP = Rp 100000

if regular => +1
    print("regular")
    if total_belanja ("regular+10000 <Y/N>")
        print(total_belanja)
if VIP dan VVIP => +1
    print("VIP dan VVIP")
else:
    print("mendapat minuman gratis")
    